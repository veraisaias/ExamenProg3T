package com.politecnicomalaga;

import java.util.List;

public class Concatenacion {
    public String concatenar(List<String> palabras){
        return String.join("",palabras);
    }
}
